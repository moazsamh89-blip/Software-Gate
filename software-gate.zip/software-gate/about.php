<?php
$activePage = 'about';
$pageTitle = 'من نحن';
require_once 'includes/header.php';
?>

<section style="padding-top:48px;">
  <div class="container">
    <div class="section-head">
      <div class="eyebrow" style="margin:0 auto 14px;display:table;">من نحن</div>
      <h2>Software Gate</h2>
      <p>بوابتك إلى عالم رقمي أكثر ذكاءً واحترافية.</p>
    </div>
    <div class="about-grid">
      <div class="about-visual">
        <h3>رسالتنا</h3>
        <p>نؤمن أن كل فكرة تستحق بوابة رقمية تليق بها. نحوّل متطلبات عملائنا إلى مواقع سريعة وآمنة وسهلة الإدارة، مبنية على أسس تقنية متينة.</p>
      </div>
      <div>
        <p style="color:var(--ink-soft);">Software Gate هي شركة متخصصة في تصميم وبرمجة المواقع الإلكترونية ولوحات التحكم المخصصة. فريقنا يجمع بين الخبرة التقنية والذوق التصميمي لتقديم حلول رقمية متكاملة تناسب الأفراد وأصحاب المشاريع والشركات على اختلاف أحجامها.</p>
        <div class="value-list">
          <div class="value-item"><div class="num">1</div><div><h4>جودة بلا مساومة</h4><p>نلتزم بمعايير برمجية وتصميمية عالية في كل مشروع.</p></div></div>
          <div class="value-item"><div class="num">2</div><div><h4>شفافية كاملة</h4><p>تتابع تقدم مشروعك خطوة بخطوة دون مفاجآت.</p></div></div>
          <div class="value-item"><div class="num">3</div><div><h4>دعم بعد الإطلاق</h4><p>علاقتنا لا تنتهي بتسليم الموقع، بل تستمر بالمتابعة والدعم.</p></div></div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
