-- ============================================================
-- Software Gate — قاعدة البيانات
-- شركة تصميم وبرمجة مواقع
-- ============================================================

CREATE DATABASE IF NOT EXISTS software_gate
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE software_gate;

-- ------------------------------------------------------------
-- جدول المدراء (لوحة التحكم)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- لإنشاء حساب المدير الأول: لا تُدرج كلمة مرور هنا يدوياً.
-- بعد استيراد هذا الملف، افتح admin/setup.php مرة واحدة من المتصفح
-- لإنشاء حساب "admin" بكلمة مرور مشفّرة بأمان عبر PHP، ثم احذف الملف فوراً.

-- ------------------------------------------------------------
-- جدول تصنيفات الخدمات (تستخدم في المشاريع والحجوزات)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO categories (name) VALUES
  ('موقع تعريفي'), ('متجر إلكتروني'), ('لوحة تحكم مخصصة'), ('تطبيق ويب'), ('أخرى')
ON DUPLICATE KEY UPDATE name = name;

-- ------------------------------------------------------------
-- جدول المشاريع / أعمال سابقة (تديره لوحة التحكم)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  category VARCHAR(100) NOT NULL,
  image_path VARCHAR(255) DEFAULT NULL,
  description TEXT,
  is_featured TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO projects (title, category, image_path, description, is_featured) VALUES
  ('متجر Lumina للإضاءة', 'متجر إلكتروني', NULL, 'متجر إلكتروني متكامل لبيع مستلزمات الإضاءة المنزلية مع نظام دفع وإدارة مخزون.', 1),
  ('موقع عيادة الدكتور سامي', 'موقع تعريفي', NULL, 'موقع تعريفي طبي مع نظام حجز مواعيد ومعرض خدمات.', 0),
  ('لوحة تحكم Foodly', 'لوحة تحكم مخصصة', NULL, 'نظام إدارة طلبات لمطاعم متعددة الفروع مع تقارير مبيعات لحظية.', 0);

-- ------------------------------------------------------------
-- جدول طلبات الحجز / الاستشارات
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(150) DEFAULT NULL,
  service VARCHAR(100) NOT NULL,
  preferred_date DATE DEFAULT NULL,
  message TEXT,
  status ENUM('جديد','تم التواصل','مكتمل') NOT NULL DEFAULT 'جديد',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- جدول باقات الأسعار (اختياري - لعرضها ديناميكياً في صفحة الأسعار)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pricing_plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  currency VARCHAR(10) DEFAULT 'ج.م',
  description VARCHAR(255),
  features TEXT COMMENT 'قائمة مميزات مفصولة بفاصلة منقوطة ؛',
  is_featured TINYINT(1) DEFAULT 0,
  sort_order INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO pricing_plans (name, price, description, features, is_featured, sort_order) VALUES
  ('الأساسية', 2500, 'موقع تعريفي بسيط', 'حتى 5 صفحات؛تصميم متجاوب؛نموذج تواصل؛دعم لمدة شهر', 0, 1),
  ('الاحترافية', 5900, 'موقع أعمال متكامل', 'صفحات غير محدودة؛لوحة تحكم لإدارة المحتوى؛تحسين SEO أساسي؛نظام حجز/تواصل؛دعم 3 أشهر', 1, 2),
  ('المتجر الإلكتروني', 9500, 'متجر بيع كامل', 'إدارة منتجات ومخزون؛بوابات دفع متعددة؛لوحة تقارير مبيعات؛دعم 6 أشهر', 0, 3);

-- ------------------------------------------------------------
-- فهارس مساعدة لتحسين الأداء
-- ------------------------------------------------------------
CREATE INDEX idx_bookings_status ON bookings (status);
CREATE INDEX idx_projects_category ON projects (category);
