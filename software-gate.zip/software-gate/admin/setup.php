<?php
/**
 * ملف إعداد لمرة واحدة: يُنشئ حساب المدير الأول بكلمة مرور مشفّرة بأمان.
 * ⚠️ مهم جداً: احذف هذا الملف من الاستضافة فور الانتهاء من إنشاء الحساب.
 */
require_once '../includes/db.php';

$done = false;
$error = '';

// امنع تشغيله لو يوجد مدير مسجّل بالفعل
$existingCount = (int) $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($existingCount > 0) {
        $error = 'يوجد حساب مدير بالفعل. احذف هذا الملف لأسباب أمنية.';
    } elseif ($username === '' || strlen($password) < 6) {
        $error = 'أدخل اسم مستخدم وكلمة مرور لا تقل عن 6 أحرف.';
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (:u, :h)');
        $stmt->execute([':u' => $username, ':h' => $hash]);
        $done = true;
    }
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إعداد حساب المدير | Software Gate</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@700;800&family=IBM+Plex+Sans+Arabic:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="login-shell">
  <div class="login-box">
    <h3>إعداد حساب المدير الأول</h3>
    <?php if ($done): ?>
      <div class="alert ok">تم إنشاء الحساب بنجاح! يمكنك الآن الدخول من <a href="login.php">صفحة تسجيل الدخول</a>.</div>
      <p><b>مهم:</b> احذف ملف <code>admin/setup.php</code> من الاستضافة الآن.</p>
    <?php elseif ($existingCount > 0): ?>
      <div class="alert err">يوجد حساب مدير بالفعل. برجاء حذف هذا الملف الآن لأسباب أمنية.</div>
    <?php else: ?>
      <?php if ($error): ?><div class="alert err"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
      <p>سيتم إنشاء حساب المدير الوحيد المسموح به. بعد الإنشاء احذف هذا الملف فوراً.</p>
      <form method="POST" action="setup.php">
        <div class="field"><label>اسم المستخدم</label><input type="text" name="username" required value="admin"></div>
        <div class="field"><label>كلمة المرور</label><input type="password" name="password" required minlength="6"></div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">إنشاء الحساب</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
