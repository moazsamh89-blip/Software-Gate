<?php
require_once 'auth_check.php';
require_once '../includes/db.php';

$msg = '';
$msgType = 'ok';

// إضافة مشروع جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = trim($_POST['title'] ?? '');
    $cat   = trim($_POST['category'] ?? '');
    $img   = trim($_POST['image_path'] ?? '');
    $desc  = trim($_POST['description'] ?? '');

    if ($title === '') {
        $msg = 'برجاء إدخال اسم المشروع.'; $msgType = 'err';
    } else {
        $stmt = $pdo->prepare('INSERT INTO projects (title, category, image_path, description) VALUES (:t,:c,:i,:d)');
        $stmt->execute([':t'=>$title, ':c'=>$cat, ':i'=>($img !== '' ? $img : null), ':d'=>($desc !== '' ? $desc : 'بدون وصف.')]);
        $msg = 'تمت إضافة المشروع بنجاح.'; $msgType = 'ok';
    }
}

// حذف مشروع
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare('DELETE FROM projects WHERE id = :id');
    $stmt->execute([':id' => (int) $_GET['delete']]);
    header('Location: dashboard.php?deleted=1');
    exit;
}
if (isset($_GET['deleted'])) { $msg = 'تم حذف المشروع.'; $msgType = 'ok'; }

$categories = $pdo->query('SELECT name FROM categories ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
$projects = $pdo->query('SELECT * FROM projects ORDER BY created_at DESC')->fetchAll();

$pageTitle = 'إدارة المشاريع';
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $pageTitle; ?> | لوحة التحكم</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="admin-top">
  <div class="container">
    <div class="a-brand">🔐 لوحة تحكم Software Gate — مرحباً <?php echo htmlspecialchars($_SESSION['admin_username']); ?></div>
    <a href="logout.php" class="admin-logout" style="text-decoration:none;">تسجيل الخروج</a>
  </div>
</div>

<div class="container admin-body">
  <div class="admin-tabs">
    <a href="dashboard.php" class="a-tab active" style="text-decoration:none;">إدارة المشاريع</a>
    <a href="bookings.php" class="a-tab" style="text-decoration:none;">إدارة الحجوزات</a>
  </div>

  <?php if ($msg): ?><div class="alert <?php echo $msgType; ?>"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

  <div class="a-card">
    <h3>إضافة مشروع جديد</h3>
    <form method="POST" action="dashboard.php">
      <input type="hidden" name="action" value="add">
      <div class="a-grid2">
        <div class="field"><label>اسم المشروع</label><input type="text" name="title" placeholder="مثال: متجر أزياء" required></div>
        <div class="field"><label>التصنيف</label>
          <select name="category">
            <?php foreach ($categories as $c): ?><option value="<?php echo htmlspecialchars($c); ?>"><?php echo htmlspecialchars($c); ?></option><?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="field"><label>رابط الصورة (اختياري)</label><input type="text" name="image_path" placeholder="https://..."></div>
      <div class="field"><label>وصف مختصر</label><textarea name="description" placeholder="وصف بسيط للمشروع..."></textarea></div>
      <button type="submit" class="btn btn-primary">إضافة المشروع</button>
    </form>
  </div>

  <div class="a-card">
    <h3>المشاريع الحالية (<?php echo count($projects); ?>)</h3>
    <?php if (empty($projects)): ?>
      <p class="small-note">لا توجد مشاريع مضافة بعد.</p>
    <?php else: ?>
      <div class="admin-item-list">
        <?php foreach ($projects as $p): ?>
          <div class="admin-item">
            <img src="<?php echo $p['image_path'] ? htmlspecialchars($p['image_path']) : ''; ?>" onerror="this.style.background='linear-gradient(135deg,#123C5F,#17B8C4)';this.removeAttribute('src');">
            <div class="info">
              <h4><?php echo htmlspecialchars($p['title']); ?></h4>
              <span><?php echo htmlspecialchars($p['category']); ?> · <?php echo htmlspecialchars(mb_substr($p['description'], 0, 60)); ?></span>
            </div>
            <a href="dashboard.php?delete=<?php echo $p['id']; ?>" class="mini-btn del" style="text-decoration:none;" onclick="return confirm('هل أنت متأكد من حذف هذا المشروع؟');">حذف</a>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
