<?php
session_start();
require_once '../includes/db.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $stmt = $pdo->prepare('SELECT * FROM admins WHERE username = :u LIMIT 1');
    $stmt->execute([':u' => $username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password_hash'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'اسم المستخدم أو كلمة المرور غير صحيحة.';
    }
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>دخول لوحة التحكم | Software Gate</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="login-shell">
  <div class="login-box">
    <div class="brand">
      <svg class="brand-mark" width="38" height="38" viewBox="0 0 100 100"><defs><linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#123C5F"/><stop offset="1" stop-color="#17B8C4"/></linearGradient></defs>
      <path d="M50 6C30 6 16 20 16 40v18l17 14 17-13 17 13 17-14V40C84 20 70 6 50 6Z" fill="url(#lg1)"/></svg>
      <span class="brand-text">SOFTWARE GATE</span>
    </div>
    <h3>دخول لوحة التحكم</h3>
    <p>هذه المنطقة مخصصة لفريق العمل فقط.</p>
    <?php if ($error): ?><div class="alert err"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" action="login.php">
      <div class="field"><label>اسم المستخدم</label><input type="text" name="username" required autofocus></div>
      <div class="field"><label>كلمة المرور</label><input type="password" name="password" required></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">دخول</button>
    </form>
  </div>
</div>
</body>
</html>
