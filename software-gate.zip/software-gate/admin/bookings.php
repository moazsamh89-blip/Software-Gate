<?php
require_once 'auth_check.php';
require_once '../includes/db.php';

// تحديث حالة الحجز
if (isset($_GET['cycle'])) {
    $id = (int) $_GET['cycle'];
    $stmt = $pdo->prepare('SELECT status FROM bookings WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $current = $stmt->fetchColumn();
    $order = ['جديد', 'تم التواصل', 'مكتمل'];
    $idx = array_search($current, $order);
    $next = $order[($idx + 1) % count($order)];
    $upd = $pdo->prepare('UPDATE bookings SET status = :s WHERE id = :id');
    $upd->execute([':s' => $next, ':id' => $id]);
    header('Location: bookings.php');
    exit;
}

// حذف حجز
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare('DELETE FROM bookings WHERE id = :id');
    $stmt->execute([':id' => (int) $_GET['delete']]);
    header('Location: bookings.php?deleted=1');
    exit;
}

$bookings = $pdo->query('SELECT * FROM bookings ORDER BY created_at DESC')->fetchAll();

$statusClass = [
    'جديد' => 'status-new',
    'تم التواصل' => 'status-contacted',
    'مكتمل' => 'status-done',
];
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إدارة الحجوزات | لوحة التحكم</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="admin-top">
  <div class="container">
    <div class="a-brand">🔐 لوحة تحكم Software Gate — مرحباً <?php echo htmlspecialchars($_SESSION['admin_username']); ?></div>
    <a href="logout.php" class="admin-logout" style="text-decoration:none;">تسجيل الخروج</a>
  </div>
</div>

<div class="container admin-body">
  <div class="admin-tabs">
    <a href="dashboard.php" class="a-tab" style="text-decoration:none;">إدارة المشاريع</a>
    <a href="bookings.php" class="a-tab active" style="text-decoration:none;">إدارة الحجوزات</a>
  </div>

  <?php if (isset($_GET['deleted'])): ?><div class="alert ok">تم حذف الطلب.</div><?php endif; ?>

  <div class="a-card">
    <h3>طلبات الحجز الواردة (<?php echo count($bookings); ?>)</h3>
    <?php if (empty($bookings)): ?>
      <p class="small-note">لا توجد طلبات حجز حتى الآن.</p>
    <?php else: ?>
    <div style="overflow-x:auto;">
      <table>
        <thead><tr><th>الاسم</th><th>الهاتف</th><th>الخدمة</th><th>التاريخ</th><th>الحالة</th><th>إجراء</th></tr></thead>
        <tbody>
          <?php foreach ($bookings as $b): ?>
          <tr>
            <td>
              <b><?php echo htmlspecialchars($b['full_name']); ?></b>
              <?php if ($b['email']): ?><br><span style="color:var(--ink-soft);font-size:12px;"><?php echo htmlspecialchars($b['email']); ?></span><?php endif; ?>
              <?php if ($b['message']): ?><br><span style="color:var(--ink-soft);font-size:12px;"><?php echo htmlspecialchars(mb_substr($b['message'],0,50)); ?></span><?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($b['phone']); ?></td>
            <td><?php echo htmlspecialchars($b['service']); ?></td>
            <td><?php echo $b['preferred_date'] ? htmlspecialchars($b['preferred_date']) : '—'; ?></td>
            <td><span class="status-pill <?php echo $statusClass[$b['status']] ?? 'status-new'; ?>"><?php echo htmlspecialchars($b['status']); ?></span></td>
            <td style="display:flex;gap:6px;flex-wrap:wrap;">
              <a href="bookings.php?cycle=<?php echo $b['id']; ?>" class="mini-btn edit" style="text-decoration:none;">تحديث الحالة</a>
              <a href="bookings.php?delete=<?php echo $b['id']; ?>" class="mini-btn del" style="text-decoration:none;" onclick="return confirm('هل أنت متأكد من حذف هذا الطلب؟');">حذف</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
