<?php
require_once 'includes/db.php';
$activePage = 'booking';
$pageTitle = 'احجز الآن';

$formMsg = '';
$formOk = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $service = trim($_POST['service'] ?? '');
    $date    = trim($_POST['date'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '' || $phone === '') {
        $formMsg = 'برجاء إدخال الاسم ورقم الهاتف.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO bookings (full_name, phone, email, service, preferred_date, message, status)
                 VALUES (:full_name, :phone, :email, :service, :preferred_date, :message, "جديد")'
            );
            $stmt->execute([
                ':full_name'      => $name,
                ':phone'          => $phone,
                ':email'          => $email !== '' ? $email : null,
                ':service'        => $service,
                ':preferred_date' => $date !== '' ? $date : null,
                ':message'        => $message,
            ]);
            $formOk = true;
            $formMsg = 'تم إرسال طلبك بنجاح! سنتواصل معك قريباً.';
        } catch (Exception $e) {
            $formMsg = 'حدث خطأ أثناء إرسال الطلب، برجاء المحاولة مرة أخرى.';
        }
    }
}

require_once 'includes/header.php';
?>

<section style="padding-top:48px;">
  <div class="container">
    <div class="section-head">
      <div class="eyebrow" style="margin:0 auto 14px;display:table;">احجز الآن</div>
      <h2>احجز استشارتك المجانية</h2>
      <p>عبّئ البيانات وسنتواصل معك خلال 48 ساعة لمناقشة تفاصيل مشروعك.</p>
    </div>
    <div class="booking-wrap">
      <div class="booking-info">
        <h3>لماذا تحجز معنا؟</h3>
        <p>استشارة أولى مجانية بالكامل لفهم احتياجاتك وتقديم أفضل حل مناسب لميزانيتك.</p>
        <div class="bi-row"><div class="ic2">📞</div><div><b>اتصل بنا</b><br><span style="opacity:.85;">+20 100 000 0000</span></div></div>
        <div class="bi-row"><div class="ic2">✉️</div><div><b>راسلنا</b><br><span style="opacity:.85;">hello@softwaregate.com</span></div></div>
        <div class="bi-row"><div class="ic2">⏱️</div><div><b>وقت الاستجابة</b><br><span style="opacity:.85;">خلال 48 ساعة عمل</span></div></div>
      </div>
      <div class="form-card">
        <?php if ($formMsg): ?>
          <div class="form-msg <?php echo $formOk ? 'ok' : 'err'; ?>" style="margin-bottom:20px;"><?php echo htmlspecialchars($formMsg); ?></div>
        <?php endif; ?>
        <?php if (!$formOk): ?>
        <form method="POST" action="booking.php">
          <div class="form-row">
            <div class="field"><label>الاسم الكامل</label><input type="text" name="name" required placeholder="اكتب اسمك" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"></div>
            <div class="field"><label>رقم الهاتف</label><input type="tel" name="phone" required placeholder="01xxxxxxxxx" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>"></div>
          </div>
          <div class="form-row">
            <div class="field"><label>البريد الإلكتروني (اختياري)</label><input type="email" name="email" placeholder="example@mail.com" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"></div>
            <div class="field"><label>نوع الخدمة</label>
              <select name="service">
                <option>موقع تعريفي</option>
                <option>متجر إلكتروني</option>
                <option>لوحة تحكم مخصصة</option>
                <option>تطبيق ويب</option>
                <option>أخرى</option>
              </select>
            </div>
          </div>
          <div class="field"><label>التاريخ المفضل للتواصل</label><input type="date" name="date"></div>
          <div class="field"><label>تفاصيل المشروع</label><textarea name="message" placeholder="أخبرنا بفكرة مشروعك..."></textarea></div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">إرسال طلب الحجز</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
