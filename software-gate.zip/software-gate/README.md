# Software Gate — موقع الشركة (PHP + MySQL)

## المتطلبات
- PHP 7.4 أو أحدث (يدعم PDO + MySQL)
- خادم MySQL / MariaDB
- سيرفر مثل Apache أو Nginx (أو `php -S localhost:8000` للتجربة محلياً)

## خطوات التشغيل

1. **إنشاء قاعدة البيانات**
   استورد ملف `sql/schema.sql` في MySQL (عبر phpMyAdmin أو سطر الأوامر):
   ```
   mysql -u root -p < sql/schema.sql
   ```
   هذا ينشئ قاعدة `software_gate` وجداول: `admins`, `projects`, `bookings`, `categories`, `pricing_plans`.

2. **ضبط بيانات الاتصال**
   افتح `includes/db.php` وعدّل:
   ```php
   $DB_HOST = 'localhost';
   $DB_NAME = 'software_gate';
   $DB_USER = 'root';
   $DB_PASS = '';
   ```

3. **إنشاء حساب المدير (خطوة أمان مهمة)**
   افتح من المتصفح: `http://yourdomain.com/admin/setup.php`
   أدخل اسم مستخدم وكلمة مرور لحساب المدير — سيتم تشفيرها تلقائياً.
   **بعد الإنشاء مباشرة احذف ملف `admin/setup.php` من الاستضافة.**

4. **تشغيل الموقع**
   وجّه الدومين إلى مجلد المشروع، أو محلياً:
   ```
   php -S localhost:8000
   ```
   ثم افتح `http://localhost:8000`

## الوصول للوحة التحكم (مخفية عن الزوار)
- لا يوجد رابط ظاهر لها في القائمة الرئيسية.
- الوصول عبر نقطة صغيرة شبه شفافة أسفل الفوتر (بجانب حقوق النشر) تؤدي إلى `admin/login.php`.
- أو مباشرة عبر الرابط: `/admin/login.php`

## هيكل الملفات
```
software-gate/
├── index.php              الرئيسية
├── about.php               من نحن
├── portfolio.php           أعمالنا السابقة (من قاعدة البيانات)
├── booking.php             صفحة الحجز (يحفظ في جدول bookings)
├── includes/
│   ├── db.php               اتصال قاعدة البيانات
│   ├── header.php            الهيدر المشترك
│   └── footer.php            الفوتر المشترك (يحتوي رابط الأدمن المخفي)
├── assets/
│   ├── style.css
│   └── script.js
├── admin/
│   ├── setup.php             إنشاء حساب المدير الأول (احذفه بعد الاستخدام)
│   ├── login.php             تسجيل الدخول
│   ├── logout.php            تسجيل الخروج
│   ├── auth_check.php        حارس الجلسة (يُستخدم داخلياً)
│   ├── dashboard.php         إدارة المشاريع (إضافة/حذف)
│   └── bookings.php          إدارة طلبات الحجز (تحديث الحالة/حذف)
└── sql/
    └── schema.sql             بنية قاعدة البيانات
```

## ملاحظات أمان
- كل الاستعلامات تستخدم Prepared Statements لمنع SQL Injection.
- كلمات المرور مخزّنة بتشفير bcrypt عبر `password_hash()`.
- لوحة التحكم محمية بجلسة PHP (`session`) — لا يمكن الوصول لصفحات `dashboard.php` أو `bookings.php` بدون تسجيل دخول.
- يُنصح بإضافة HTTPS على السيرفر، وتغيير اسم مجلد `admin` إلى اسم غير متوقع لمزيد من التمويه إن أردت.
