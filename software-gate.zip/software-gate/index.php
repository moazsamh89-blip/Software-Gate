<?php
require_once 'includes/db.php';
$activePage = 'home';
$pageTitle = 'الرئيسية';

// عدد المشاريع لعرضه في الإحصائيات
$projectCount = 0;
try {
    $projectCount = (int) $pdo->query('SELECT COUNT(*) FROM projects')->fetchColumn();
} catch (Exception $e) { $projectCount = 0; }

// باقات الأسعار
$plans = [];
try {
    $plans = $pdo->query('SELECT * FROM pricing_plans ORDER BY sort_order ASC')->fetchAll();
} catch (Exception $e) { $plans = []; }

require_once 'includes/header.php';
?>

<section class="hero">
  <div class="container hero-grid">
    <div>
      <div class="eyebrow"><span class="dot"></span> نصمم وننشئ مواقع احترافية</div>
      <h1 class="hero-title">بوابتك نحو <span class="accent">حضور رقمي</span> يليق بطموحك</h1>
      <p class="hero-sub">Software Gate شريكك في تصميم وبرمجة المواقع الإلكترونية بجودة عالية وأسعار مميزة تناسب الأفراد والشركات الناشئة والمؤسسات.</p>
      <div class="hero-actions">
        <a href="booking.php" class="btn btn-primary">احجز استشارة مجانية →</a>
        <a href="portfolio.php" class="btn btn-ghost">شاهد أعمالنا</a>
      </div>
      <div class="hero-stats">
        <div><b><?php echo $projectCount; ?>+</b><span>مشروع منجز</span></div>
        <div><b>+98%</b><span>رضا العملاء</span></div>
        <div><b>48h</b><span>وقت الاستجابة</span></div>
      </div>
    </div>
    <div class="gate-stage">
      <svg viewBox="0 0 420 460" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="arcGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#123C5F"/><stop offset="1" stop-color="#17B8C4"/></linearGradient>
          <radialGradient id="glowGrad" cx="50%" cy="35%" r="60%"><stop offset="0" stop-color="#BFF3F6" stop-opacity=".9"/><stop offset="1" stop-color="#BFF3F6" stop-opacity="0"/></radialGradient>
        </defs>
        <path d="M60 430 V180 C60 90 130 40 210 40 C290 40 360 90 360 180 V430" fill="none" stroke="url(#arcGrad)" stroke-width="20"/>
        <ellipse cx="210" cy="200" rx="95" ry="150" fill="url(#glowGrad)"/>
        <g transform="translate(150,420) rotate(-26)"><rect x="-70" y="-230" width="70" height="230" fill="#0E3A5C"/></g>
        <g transform="translate(270,420) rotate(26)"><rect x="0" y="-230" width="70" height="230" fill="#17B8C4"/></g>
        <text class="bit" x="150" y="150" font-size="20" style="animation-delay:.2s">1</text>
        <text class="bit" x="180" y="120" font-size="20" style="animation-delay:1s">0</text>
        <text class="bit" x="240" y="140" font-size="20" style="animation-delay:1.8s">1</text>
        <text class="bit" x="270" y="170" font-size="20" style="animation-delay:.7s">0</text>
        <text class="bit" x="205" y="105" font-size="20" style="animation-delay:2.3s">{ }</text>
      </svg>
    </div>
  </div>
</section>

<section class="badge-strip">
  <div class="container">
    <div class="section-head">
      <div class="eyebrow" style="margin:0 auto 14px;display:table;">خدماتنا</div>
      <h2>كل ما تحتاجه لبناء حضورك الرقمي</h2>
      <p>من التصميم إلى الإطلاق والدعم، نوفر خدمات متكاملة تحت سقف واحد.</p>
    </div>
    <div class="grid-3">
      <div class="card"><div class="ic">🖥️</div><h3>تصميم مواقع احترافية</h3><p>واجهات عصرية متجاوبة مع جميع الأجهزة، مصممة خصيصاً لهوية علامتك التجارية.</p></div>
      <div class="card"><div class="ic">🛒</div><h3>متاجر إلكترونية</h3><p>متاجر متكاملة مع بوابات دفع وإدارة مخزون وتجربة شراء سلسة لعملائك.</p></div>
      <div class="card"><div class="ic">⚙️</div><h3>لوحات تحكم مخصصة</h3><p>أنظمة إدارة داخلية تمنحك تحكماً كاملاً في محتوى وبيانات موقعك بسهولة.</p></div>
      <div class="card"><div class="ic">🚀</div><h3>تحسين الأداء وSEO</h3><p>سرعة تحميل عالية وظهور أفضل في محركات البحث لزيادة زوارك.</p></div>
      <div class="card"><div class="ic">🔧</div><h3>الصيانة والدعم الفني</h3><p>متابعة مستمرة وتحديثات دورية لضمان عمل موقعك بأفضل حال.</p></div>
      <div class="card"><div class="ic">📱</div><h3>تطبيقات ويب تفاعلية</h3><p>حلول برمجية مخصصة تحوّل أفكارك إلى أدوات رقمية فعّالة.</p></div>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="section-head"><h2>رحلة مشروعك معنا</h2><p>عملية واضحة من أول فكرة حتى الإطلاق.</p></div>
    <div class="timeline">
      <div class="tl-step"><div class="step-no">1</div><h4>الاستشارة والحجز</h4><p>تحجز موعدك وتخبرنا بفكرة مشروعك واحتياجاتك.</p></div>
      <div class="tl-step"><div class="step-no">2</div><h4>التصميم</h4><p>نصمم واجهة تعكس هويتك ونشاركك المعاينة للتعديل.</p></div>
      <div class="tl-step"><div class="step-no">3</div><h4>البرمجة والتطوير</h4><p>نبني الموقع بأحدث التقنيات مع اختبار شامل.</p></div>
      <div class="tl-step"><div class="step-no">4</div><h4>الإطلاق والدعم</h4><p>ننشر موقعك ونقدم دعماً مستمراً بعد الإطلاق.</p></div>
    </div>
  </div>
</section>

<section class="badge-strip">
  <div class="container">
    <div class="section-head"><h2>باقات أسعار مميزة</h2><p>اختر الباقة التي تناسب حجم مشروعك، وجميعها قابلة للتخصيص.</p></div>
    <div class="pricing-wrap">
      <?php foreach ($plans as $plan): $features = array_filter(explode('؛', $plan['features'])); ?>
      <div class="plan <?php echo $plan['is_featured'] ? 'featured' : ''; ?>">
        <?php if ($plan['is_featured']): ?><span class="tag">الأكثر طلباً</span><?php endif; ?>
        <h3><?php echo htmlspecialchars($plan['name']); ?></h3>
        <p style="color:var(--ink-soft);font-size:13.5px;margin:0;"><?php echo htmlspecialchars($plan['description']); ?></p>
        <div class="price"><?php echo number_format($plan['price'], 0); ?><span> <?php echo htmlspecialchars($plan['currency']); ?></span></div>
        <ul>
          <?php foreach ($features as $f): ?><li><?php echo htmlspecialchars(trim($f)); ?></li><?php endforeach; ?>
        </ul>
        <a href="booking.php" class="btn <?php echo $plan['is_featured'] ? 'btn-primary' : 'btn-ghost'; ?>" style="width:100%;justify-content:center;">اطلب الآن</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="section-head"><h2>أسئلة شائعة</h2></div>
    <div class="faq">
      <div class="faq-item"><div class="faq-q"><span>كم تستغرق مدة تصميم الموقع؟</span><span class="plus">+</span></div><div class="faq-a">حسب حجم المشروع، عادة من أسبوعين إلى 6 أسابيع للمواقع المتوسطة والمتاجر الإلكترونية.</div></div>
      <div class="faq-item"><div class="faq-q"><span>هل يمكنني تعديل الموقع بنفسي بعد التسليم؟</span><span class="plus">+</span></div><div class="faq-a">نعم، نوفر لوحة تحكم سهلة الاستخدام تتيح لك إضافة وتعديل المحتوى دون الحاجة لخبرة برمجية.</div></div>
      <div class="faq-item"><div class="faq-q"><span>هل تقدمون دعماً بعد الإطلاق؟</span><span class="plus">+</span></div><div class="faq-a">بالتأكيد، جميع باقاتنا تشمل فترة دعم فني مجانية بعد التسليم.</div></div>
      <div class="faq-item"><div class="faq-q"><span>كيف أبدأ مشروعي معكم؟</span><span class="plus">+</span></div><div class="faq-a">ببساطة احجز استشارتك المجانية من صفحة الحجز وسيتواصل معك فريقنا خلال 48 ساعة.</div></div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
