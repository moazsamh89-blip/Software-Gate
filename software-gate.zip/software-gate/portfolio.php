<?php
require_once 'includes/db.php';
$activePage = 'portfolio';
$pageTitle = 'أعمالنا السابقة';

$projects = [];
try {
    $projects = $pdo->query('SELECT * FROM projects ORDER BY created_at DESC')->fetchAll();
} catch (Exception $e) { $projects = []; }

$categories = ['الكل'];
foreach ($projects as $p) {
    if (!in_array($p['category'], $categories)) $categories[] = $p['category'];
}

require_once 'includes/header.php';
?>

<section style="padding-top:48px;">
  <div class="container">
    <div class="section-head">
      <div class="eyebrow" style="margin:0 auto 14px;display:table;">أعمالنا</div>
      <h2>مشاريع أنجزناها</h2>
      <p>نماذج من المواقع التي صممناها وبرمجناها لعملائنا.</p>
    </div>

    <div class="portfolio-filter">
      <?php foreach ($categories as $i => $cat): ?>
        <button class="pf-btn <?php echo $i===0?'active':''; ?>" data-cat="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></button>
      <?php endforeach; ?>
    </div>

    <?php if (empty($projects)): ?>
      <div class="empty-state">لا توجد مشاريع مضافة بعد. تابعونا قريباً!</div>
    <?php else: ?>
    <div class="pf-grid">
      <?php foreach ($projects as $p): ?>
        <div class="pf-card" data-cat="<?php echo htmlspecialchars($p['category']); ?>">
          <div class="pf-thumb">
            <?php if (!empty($p['image_path'])): ?>
              <img src="<?php echo htmlspecialchars($p['image_path']); ?>" alt="<?php echo htmlspecialchars($p['title']); ?>" onerror="this.parentElement.innerHTML='<span class=&quot;ph&quot;><?php echo htmlspecialchars($p['title']); ?></span>'">
            <?php else: ?>
              <span class="ph"><?php echo htmlspecialchars($p['title']); ?></span>
            <?php endif; ?>
          </div>
          <div class="pf-body">
            <div class="cat"><?php echo htmlspecialchars($p['category']); ?></div>
            <h3><?php echo htmlspecialchars($p['title']); ?></h3>
            <p><?php echo htmlspecialchars($p['description']); ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
