<?php
/**
 * الاتصال بقاعدة البيانات
 * عدّل البيانات أدناه لتطابق بيانات الاستضافة الخاصة بك
 */
$DB_HOST = 'localhost';
$DB_NAME = 'software_gate';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die('تعذر الاتصال بقاعدة البيانات. برجاء التأكد من إعدادات الاتصال في includes/db.php');
}
