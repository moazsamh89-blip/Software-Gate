<footer>
  <div class="container">
    <div class="foot-grid">
      <div>
        <div class="foot-brand">
          <svg width="30" height="30" viewBox="0 0 100 100"><path d="M50 6C30 6 16 20 16 40v18l17 14 17-13 17 13 17-14V40C84 20 70 6 50 6Z" fill="#17B8C4"/></svg>
          SOFTWARE GATE
        </div>
        <p>بوابتك نحو حضور رقمي احترافي. نصمم مواقع وأنظمة تليق بطموحك.</p>
      </div>
      <div>
        <h4>روابط سريعة</h4>
        <ul>
          <li><a href="index.php">الرئيسية</a></li>
          <li><a href="about.php">من نحن</a></li>
          <li><a href="portfolio.php">أعمالنا السابقة</a></li>
          <li><a href="booking.php">احجز الآن</a></li>
        </ul>
      </div>
      <div>
        <h4>تواصل معنا</h4>
        <ul>
          <li>hello@softwaregate.com</li>
          <li>+20 100 000 0000</li>
          <li>القاهرة، مصر</li>
        </ul>
      </div>
    </div>
    <div class="foot-bottom">
      <span>© <?php echo date('Y'); ?> Software Gate. جميع الحقوق محفوظة.</span>
      <!-- رابط لوحة التحكم مخفي بصرياً: أيقونة صغيرة شبه شفافة بلا نص يشير لدورها -->
      <span class="secret-dot" title=""><a href="admin/login.php">•</a></span>
    </div>
  </div>
</footer>
<script src="assets/script.js"></script>
</body>
</html>
