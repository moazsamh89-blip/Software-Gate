<?php
// $activePage يجب تعريفه قبل استدعاء هذا الملف: home | about | portfolio | booking
if (!isset($activePage)) { $activePage = ''; }
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' : ''; ?>Software Gate</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header>
  <div class="container nav-wrap">
    <a href="index.php" class="brand">
      <svg class="brand-mark" viewBox="0 0 100 100"><defs><linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#123C5F"/><stop offset="1" stop-color="#17B8C4"/></linearGradient></defs>
      <path d="M50 6C30 6 16 20 16 40v18l17 14 17-13 17 13 17-14V40C84 20 70 6 50 6Z" fill="url(#lg1)"/>
      <path d="M50 30v22M40 34l7 9M60 34l-7 9" stroke="#fff" stroke-width="3" stroke-linecap="round" fill="none"/></svg>
      <span class="brand-text">SOFTWARE GATE<small>Building the Digital Future</small></span>
    </a>
    <nav class="nav-links" id="navLinks">
      <a href="index.php" class="<?php echo $activePage==='home'?'active':''; ?>">الرئيسية</a>
      <a href="about.php" class="<?php echo $activePage==='about'?'active':''; ?>">من نحن</a>
      <a href="portfolio.php" class="<?php echo $activePage==='portfolio'?'active':''; ?>">أعمالنا السابقة</a>
      <a href="booking.php" class="nav-cta <?php echo $activePage==='booking'?'active':''; ?>">احجز استشارتك</a>
    </nav>
    <button class="burger" id="burgerBtn">☰</button>
  </div>
</header>
